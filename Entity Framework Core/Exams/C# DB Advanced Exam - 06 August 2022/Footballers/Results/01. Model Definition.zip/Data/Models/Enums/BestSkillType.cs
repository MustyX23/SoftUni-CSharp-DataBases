﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Footballers.Data.Models.Enums
{
    public enum BestSkillType
    {
        Defence = 1,
        Dribble = 2,
        Pass = 3, 
        Shoot = 4,
        Speed = 5
    }
}
