﻿namespace BookShop
{
    using BookShop.Models.Enums;
    using Data;
    using Initializer;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);

            string result = GetGoldenBooks(db);

            Console.WriteLine(result);
        }
        public static string GetGoldenBooks(BookShopContext context)
        {
            StringBuilder sb = new StringBuilder();

            var goldenEdition = Enum.Parse<EditionType>("Gold", true);

            var books = context.Books
                .Where(b => b.EditionType == goldenEdition && b.Copies < 5000)
                .OrderBy(b => b.BookId)
                .ToArray();

            /*
             * Return in a single string the titles of 
             * the golden edition books that have less than 5000 copies
             * , each on a new line. Order them by BookId ascending.
             */

            foreach (var bookTitle in books)
            {
                sb.AppendLine(bookTitle.Title);
            }

            return sb.ToString().TrimEnd();
        }
    }
}


