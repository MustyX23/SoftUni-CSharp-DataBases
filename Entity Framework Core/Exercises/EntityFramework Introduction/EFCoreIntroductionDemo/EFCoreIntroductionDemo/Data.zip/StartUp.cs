﻿using EFCoreIntroductionDemo.Models;

public class StartUp
{
    private static void Main(string[] args)
    {
        var db = new SoftUniContext();

        var employees = db.Employees
            .Select(e => new { Name = e.FirstName + " " +
                    e.LastName, e.Address }).OrderBy(x => x.Name);

        foreach (var employee in employees)
        {
            Console.WriteLine(employee.Name + " " + employee.Address);
        }


    }
}