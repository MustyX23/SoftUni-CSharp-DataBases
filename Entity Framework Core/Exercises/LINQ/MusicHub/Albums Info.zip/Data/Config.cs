﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicHub.Data
{
    public static class Config
    {
        public const string ConnectionString = "Server=.;Database=MusicHub;" +
                    "Trusted_Connection=true;TrustServerCertificate=true";
    }
}
