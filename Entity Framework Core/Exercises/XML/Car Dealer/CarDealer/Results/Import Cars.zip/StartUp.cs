﻿using AutoMapper;
using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using Castle.Core.Internal;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            var db = new CarDealerContext();

            db.Database.EnsureDeleted();
            db.Database.EnsureCreated();

            string suppliersXML = File.ReadAllText(@"../../../Datasets/suppliers.xml");
            ImportSuppliers(db, suppliersXML);

            string partsXML = File.ReadAllText(@"../../../Datasets/parts.xml");
            ImportParts(db, partsXML);

            string carsXML = File.ReadAllText(@"../../../Datasets/cars.xml");
            Console.WriteLine(ImportCars(db, carsXML));
        }
        private static IMapper InitializeAutoMapper()
        {
            return new Mapper(new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<CarDealerProfile>();

            }));
           
        }

        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            IMapper mapper = InitializeAutoMapper();

            XmlHelper xmlHelper = new XmlHelper();

            var suppliers = new HashSet<Supplier>(); 

            var supplierDTOS = xmlHelper.Deserialize<ImportSupplierDTO[]>(inputXml, "Suppliers");

            foreach (var supplierDTO in supplierDTOS)
            {
                if (string.IsNullOrEmpty(supplierDTO.Name))
                {
                    continue;
                }

                Supplier supplier = mapper.Map<Supplier>(supplierDTO);

                suppliers.Add(supplier);
            }

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count}";
        }

        public static string ImportParts(CarDealerContext context, string inputXml)
        {
            XmlHelper xmlHelper = new XmlHelper();

            IMapper mapper = InitializeAutoMapper();

            var parts = new HashSet<Part>();

            var partsDTOS = xmlHelper.Deserialize<ImportPartsDTO[]>(inputXml, "Parts");

            foreach (var partsDTO in partsDTOS)
            {
                if (string.IsNullOrEmpty(partsDTO.Name))
                {
                    continue;
                }

                if (!partsDTO.SupplierId.HasValue || !context.Suppliers.Any(s => s.Id == partsDTO.SupplierId))
                {
                    continue;
                }

                Part part = mapper.Map<Part>(partsDTO);

                parts.Add(part);
            }


            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Count}";
        }

        public static string ImportCars(CarDealerContext context, string inputXml)
        {
            IMapper mapper = InitializeAutoMapper();
            XmlHelper xmlHelper = new XmlHelper();

            ImportCarDTO[] carDtos =
                xmlHelper.Deserialize<ImportCarDTO[]>(inputXml, "Cars");

            ICollection<Car> validCars = new HashSet<Car>();
            foreach (ImportCarDTO carDto in carDtos)
            {
                if (string.IsNullOrEmpty(carDto.Make) ||
                    string.IsNullOrEmpty(carDto.Model))
                {
                    continue;
                }

                Car car = mapper.Map<Car>(carDto);

                foreach (var partDto in carDto.Parts.DistinctBy(p => p.PartId))
                {
                    if (!context.Parts.Any(p => p.Id == partDto.PartId))
                    {
                        continue;
                    }

                    PartCar carPart = new PartCar()
                    {
                        PartId = partDto.PartId
                    };
                    car.PartsCars.Add(carPart);
                }

                validCars.Add(car);
            }

            context.Cars.AddRange(validCars);
            context.SaveChanges();

            return $"Successfully imported {validCars.Count}";

        }


    }
}