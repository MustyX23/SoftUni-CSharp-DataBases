﻿using AutoMapper;
using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using Castle.Core.Internal;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            var db = new CarDealerContext();

            db.Database.EnsureDeleted();
            db.Database.EnsureCreated();

            string suppliersXML = File.ReadAllText(@"../../../Datasets/suppliers.xml");
            Console.WriteLine(ImportSuppliers(db, suppliersXML));
        }
        private static IMapper InitializeAutoMapper()
        {
            return new Mapper(new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<CarDealerProfile>();

            }));
           
        }

        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            IMapper mapper = InitializeAutoMapper();

            XmlHelper xmlHelper = new XmlHelper();

            var suppliers = new HashSet<Supplier>(); 

            var supplierDTOS = xmlHelper.Deserialize<ImportSupplierDTO[]>(inputXml, "Suppliers");

            foreach (var supplierDTO in supplierDTOS)
            {
                if (string.IsNullOrEmpty(supplierDTO.Name))
                {
                    continue;
                }

                Supplier supplier = mapper.Map<Supplier>(supplierDTO);

                suppliers.Add(supplier);
            }

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count}";
        }
    }
}