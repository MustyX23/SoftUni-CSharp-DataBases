﻿using ProductShop.Data;
using ProductShop.DTOs.Import;
using ProductShop.Models;
using System;
using System.Reflection.PortableExecutable;
using System.Xml;
using System.Xml.Serialization;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {
            var db = new ProductShopContext();

            db.Database.EnsureDeleted();
            db.Database.EnsureCreated();

            string xmlUsers = File.ReadAllText(@"../../../Datasets/users.xml");
            ImportUsers(db, xmlUsers);

            string xmlProducts = File.ReadAllText(@"../../../Datasets/products.xml");
            ImportProducts(db, xmlProducts);

            string xmlCategories = File.ReadAllText(@"../../../Datasets/categories.xml");
            ImportCategories(db, xmlCategories);

            string xmlCategorieProducts= File.ReadAllText(@"../../../Datasets/categories-products.xml");
            Console.WriteLine(ImportCategoryProducts(db, xmlCategorieProducts));
        }
        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(UserDTO[]), new XmlRootAttribute("Users"));

            var usersDtos = (UserDTO[])serializer.Deserialize(new StringReader(inputXml));

            List<User> users = new List<User>();

            foreach (var userDto in usersDtos)
            {
                var user = new User()
                {
                    FirstName = userDto.FirstName,
                    LastName = userDto.LastName,
                    Age = userDto.Age
                };
                users.Add(user);
            }

            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Count()}";
        }

        public static string ImportProducts(ProductShopContext context, string inputXml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(ProductDTO[]), new XmlRootAttribute("Products"));

            var productsDTOS = (ProductDTO[])serializer.Deserialize(new StringReader(inputXml));

            Product[] products = productsDTOS
                .Select(p => new Product()
                {
                    Name = p.Name,
                    Price = p.Price,
                    SellerId = p.SellerId,
                    BuyerId = p.BuyerId
                })
                .ToArray();

            context.Products.AddRange(products);
            context.SaveChanges();

            return $"Successfully imported {products.Count()}";
        }

        public static string ImportCategories(ProductShopContext context, string inputXml)
        {
            var serializer = new XmlSerializer(typeof(CategoryDTO[]), new XmlRootAttribute("Categories"));

            var categoriesDTOS = (CategoryDTO[])serializer.Deserialize(new StringReader(inputXml));

            var categories = categoriesDTOS
                .Select(c => new Category()
                {
                    Name = c.Name
                })
                .ToArray();

            context.Categories.AddRange(categories);
            context.SaveChanges();

            return $"Successfully imported {categories.Count()}";
        }

        public static string ImportCategoryProducts(ProductShopContext context, string inputXml)
        {
            var xmlSerializer = new XmlSerializer(typeof(CategoryProductDTO[]), new XmlRootAttribute("CategoryProducts"));

            var categoryProductsDTOS = (CategoryProductDTO[])xmlSerializer.Deserialize(new StringReader(inputXml));

            var categoryProducts = categoryProductsDTOS
                .Select(c => new CategoryProduct()
                {
                    CategoryId = c.CategoryId,
                    ProductId = c.ProductId
                })
                .ToList();

            context.CategoryProducts.AddRange(categoryProducts);
            context.SaveChanges();

            return $"Successfully imported {categoryProducts.Count}";
        }
    }
}